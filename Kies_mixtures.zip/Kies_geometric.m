function izh = Kies_geometric( beta,p,x );

%PDF of a geometric mixture evaluated at a point x. 

f=@(t)(p*beta*exp((t./(1-t)).^beta).*t.^(beta-1))./((exp((t./(1-t)).^beta)-1+p).^2.*(1-t).^(beta+1));
s=0.001;
st=(s:s:1-s);
ft=f(st);
ft(isnan(ft))=0;
plot(st,ft), hold on
izh=f(x);

end

