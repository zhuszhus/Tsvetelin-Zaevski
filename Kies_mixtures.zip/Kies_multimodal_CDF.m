function izh = Kies_multimodal_CDF( lambda,beta,p,x );

%CDF of a multi-modal mixture evaluated at a point x.

n=length(p);
f=@(t)0;

for j=1:n
    f=@(t)f(t)+p(j)*kies_cdf( lambda(j),beta(j),t );
end

st=(0.0:0.001:1);
ft=f(st);
plot(st,ft,'b'), hold on
izh=f(x);

end

