function izh = Kies_multimodal( lambda,beta,p,x );

%PDF of a multi-modal mixture evaluated at a point x.

n=length(p);
f=@(t)0;

for j=1:n
    f=@(t)f(t)+p(j)*kies_density_0_1( lambda(j),beta(j),t );
end

s=0.0001;
st=(s:s:1-s);
ft=f(st);
plot(st,ft), hold on
izh=f(x);

end

