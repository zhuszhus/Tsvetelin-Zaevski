function izh = Kies_binomial_lin( beta,a,b,p,n,x );

%PDF of a linear transformation of a bi-mofal  mixture evaluated at a point x. 

f=@(t)beta*exp(-b*(t./(1-t)).^beta).*(t.^(beta-1)./(1-t).^(beta+1)).*(1-p+p*exp(-a*(t./(1-t)).^beta)).^(n-1).*(b-b*p+p*(n*a+b)*exp(-a*(t./(1-t)).^beta));
izh=f(x);

s=0.0001;
st=(0.005:s:1-s);
ft=f(st);
plot(st,ft), hold on


end

