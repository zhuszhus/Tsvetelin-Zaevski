function izh = Kies_exponential_lin( beta,a,b,teta,x );

%PDF of a linear transformation of an exponential  mixture evaluated at a point x. 

f=@(t)teta*beta*t.^(beta-1).*exp(-b*(t./(1-t)).^beta).*(b*(teta*(1-t).^beta+a*t.^beta)+a*(1-t).^beta)./((teta*(1-t).^beta+a*t.^beta).^2.*(1-t));

s=0.0001;
st=(0.005:s:1-s);
ft=f(st);
plot(st,ft), hold on
izh=f(x);

end

