function izh = Kies_geometric_CDF( beta,p,x );

%CDF of a geometric mixture evaluated at a point x.

f=@(t)1-p/(exp((t/(1-t))^beta)+p-1);


st=(0.0:0.001:1);
for j=1:length(st)
ft(j)=f(st(j));
end
plot(st,ft,'b'), hold on
izh=f(x);

end

