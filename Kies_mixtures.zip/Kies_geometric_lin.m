function izh = Kies_geometric_lin( beta,a,b,p,x );

%PDF of a linear transformation of a geometric mixture evaluated at a point x.

f=@(t)p*beta*t.^(beta-1).*((b+a)*exp((a-b)*(t./(1-t)).^beta)+b*(p-1)*exp(-b*(t./(1-t)).^beta))./((exp(a*(t./(1-t)).^beta)-1+p).^2.*(1-t).^(beta+1));

s=0.0001;
st=(0.005:s:1-s);
ft=f(st);
plot(st,ft), hold on
izh=f(x);

end

