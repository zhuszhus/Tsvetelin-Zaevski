function izh = Kies_binomial( beta,p,n,x );

%PDF of a bi-modal  mixture evaluated at a point x. 

f=@(t)beta*exp(-(t./(1-t)).^beta).*(t.^(beta-1)./(1-t).^(beta+1)).*(1-p+p*exp(-(t./(1-t)).^beta)).^(n-1).*(1-p+p*(n+1)*exp(-(t./(1-t)).^beta));

s=0.001;
st=(0:s:1-s);
ft=f(st);
plot(st,ft), hold on
izh=f(x);

end

