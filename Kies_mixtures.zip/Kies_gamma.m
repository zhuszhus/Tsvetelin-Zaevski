function izh = Kies_gamma( beta,teta,alpha,x );

%PDF of a gamma  mixture evaluated at a point x. 

f=@(t)(alpha*teta^alpha*beta*t.^(beta-1).*(1-t).^(alpha*beta-1))./(teta*(1-t).^beta+t.^beta).^(alpha+1);

s=0.000001;
st=(0.01:s:1-s);
ft=f(st);
ft(isnan(ft))=0;
plot(st,ft), hold on
izh=f(x);

end

