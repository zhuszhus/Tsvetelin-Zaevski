function izh = Kies_beta_CDF( beta,teta,a,x );

%CDF of a beta-Kies mixture evaluated at a point x. 

f=@(t)1-hypergeom(a,a+teta,-(t/(1-t))^beta);


st=(0.0:0.001:1);
for j=1:length(st)
ft(j)=f(st(j));
end
plot(st,ft,'b'), hold on
izh=f(x);

end

