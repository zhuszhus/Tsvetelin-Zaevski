function izh = Kies_exponential( beta,teta,x );

%PDF of an exponential  mixture evaluated at a point x. 

f=@(t)(teta*beta*t.^(beta-1).*(1-t).^(beta-1))./(teta*(1-t).^beta+t.^beta).^2;

s=0.0001;
st=(s:s:1-s);
ft=f(st);
plot(st,ft), hold on
izh=f(x);

end

