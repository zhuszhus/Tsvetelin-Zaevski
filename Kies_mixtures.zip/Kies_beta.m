function izh = Kies_beta( beta,alpha,teta,x );

%PDF of a beta-Kies mixture evaluated at a point x. 



f=@(t)(alpha*beta/(alpha+teta))*hypergeom(alpha+1,alpha+teta+1,-(t./(1-t)).^beta).*(t.^(beta-1)./((1-t).^(beta+1)));

s=0.0001;
st=(0.0001:s:1-s);
ft=f(st);
ft(isnan(ft))=0;
plot(st,ft), hold on
izh=f(x);


end

