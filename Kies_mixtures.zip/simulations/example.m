% Genarates n-dimensional vector of an exponential Kies mixture with
% parameters $beta$ and $lam$. It is % saved as the variable $t$. The 
% related values at ll nodes are calculated % and saved as the variable $tt$.
% The stimation is derived as the variable $c$. % We repeat this procedure 
% $k$ times and save the results in the variable % $cc$.The averaged 
% results for the prameters are the first outcome. Next are
% provided the percent of the estimations that deviate more than delta from
% the original values. The last two lines are for the number of deviations 
% larger than $\delta\beta$ and $\delta\lam$, respectively.

clear cc
opt=optimset('MaxIter',10^(100),'TolX',10^(-100),'MaxFunEvals',10^(100));
ll=50;
k=1000;
 n=1000000;
 lam=3;
 be=2;
 delta=0.01;
 ee=[0,0];
 for j=1:k
[ t ] =generate_Kies_exp(be,lam,n);
clear tt
tt=zeros(1,ll);
for jj=1:length(t)
if t(jj)==1
    h=floor(t(jj)*ll);
else
h=floor(t(jj)*ll)+1;
end
tt(h)=tt(h)+1;
end
tt=ll*tt/n;
f=@(s) cost_exp_test(s,tt);
[c,d]=fminsearchbnd(f,[1,1],[0,0],[6,6],opt);
cc(j,:)=c;
ee=ee+c;
end
ee/k
100*sum(abs(cc(:,1)-be)>delta)/k
100*sum(abs(cc(:,2)-lam)>delta)/k
100*sum(abs(cc(:,1)-be)>be*delta)/k
100*sum(abs(cc(:,2)-lam)>lam*delta)/k

