function t = Kies_exponential_quantile(beta,teta,x);

%quantile function of an exponential mixture

t=(teta^(1/beta).*x.^(1/beta))./(teta^(1/beta)*x.^(1/beta)+(1-x).^(1/beta));


end