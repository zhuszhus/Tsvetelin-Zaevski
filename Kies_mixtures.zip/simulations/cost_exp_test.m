function cost = cost_exp_test(s,values);

%cost function for estimating an exponential mixture

ep=10^(-5);
ll=50;
xx=(1/(2*ll):1/ll:1-1/(2*ll));
cost=sum(abs(log((ep+Kies_exponential(s(1),s(2),xx )./(ep+values)))));

end