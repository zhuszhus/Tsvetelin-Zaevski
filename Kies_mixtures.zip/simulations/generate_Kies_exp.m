function [ t ] =generate_Kies_exp( beta,teta,N);

%generating N random numbers distributed through an exponential mixture

u=rand(1,N); 
t= Kies_exponential_quantile(beta,teta,u);


end

