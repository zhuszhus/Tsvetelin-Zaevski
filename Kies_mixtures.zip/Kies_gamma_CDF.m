function izh = Kies_gamma_CDF( beta,teta,a,x );

%CDF of a gamma mixture evaluated at a point x. 

f=@(t)1-((teta*(1-t)^beta)/(teta*(1-t)^beta+t^beta))^a;


st=(0.0:0.001:1);
for j=1:length(st)
ft(j)=f(st(j));
end
plot(st,ft,'b'), hold on
izh=f(x);

end

